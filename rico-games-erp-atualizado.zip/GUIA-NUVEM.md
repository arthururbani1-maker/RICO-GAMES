# Guia: colocar o Rico Games ERP online (acesso de qualquer lugar)

Hoje o sistema salva os dados no computador onde ele roda. Seguindo este guia, tudo o que o funcionário lançar na loja passa a aparecer para você de casa, do celular ou de qualquer lugar — em tempo real.

São duas etapas, ambas gratuitas e levam uns 15 minutos:

1. **Banco de dados na nuvem** (Supabase) — onde os dados ficam guardados online.
2. **Hospedar o sistema na internet** (Netlify) — para abrir por um endereço (site) em vez de um arquivo.

---

## Parte 1 — Criar o banco de dados (Supabase)

1. Acesse **https://supabase.com** e clique em **Start your project**. Crie a conta (pode usar o Google).
2. Clique em **New project**. Dê um nome (ex: `rico-games`), crie uma senha de banco (guarde-a) e escolha a região mais próxima (ex: São Paulo). Clique em **Create new project** e aguarde ~2 minutos.
3. No menu lateral, abra **SQL Editor** → **New query**, cole o código abaixo e clique em **Run**:

```sql
create table if not exists erp_state (
  id text primary key,
  data jsonb,
  rev bigint default 0,
  updated_at timestamptz default now()
);

alter table erp_state enable row level security;

create policy "acesso total via chave anon"
  on erp_state for all
  using (true) with check (true);
```

   Isso cria a tabela onde o sistema vai guardar tudo.

4. Agora pegue as suas chaves: menu **Project Settings** (engrenagem) → **API**. Copie dois valores:
   - **Project URL** (ex: `https://abcdefgh.supabase.co`)
   - **anon public** (uma chave longa que começa com `eyJ...`)

Guarde esses dois valores — você vai colá-los no sistema.

---

## Parte 2 — Conectar o sistema à nuvem

1. Abra o sistema, entre como **admin** e vá em **Configurações**.
2. Na seção **☁️ Sincronização na nuvem**, cole a **URL do projeto** e a **chave anon**.
3. Clique em **Conectar e testar**. Se aparecer "Conectado à nuvem!", deu certo. ✅

> **Importante:** faça este passo primeiro no **computador principal** (o que já tem os seus dados). Os dados sobem para a nuvem. Depois, ao conectar os outros aparelhos, eles vão **baixar** esses dados.

---

## Parte 3 — Hospedar o sistema na internet (Netlify)

Assim o funcionário abre um endereço (ex: `ricogames.netlify.app`) de qualquer computador/celular, em vez de um arquivo no PC.

1. Compacte a pasta **ERP RICO GAMES** inteira em um arquivo `.zip` (clique com o botão direito → Comprimir).
2. Acesse **https://app.netlify.com/drop**.
3. Arraste o `.zip` (ou a pasta) para a área indicada. Em segundos o Netlify gera um endereço público.
4. (Opcional) Em **Site settings → Change site name**, troque para algo como `ricogames`.
5. Pronto: acesse o endereço pelo celular ou outro PC, faça login e conecte na nuvem (Parte 2) com as mesmas chaves.

---

## Como fica o dia a dia

- O **funcionário** abre o endereço na loja, faz login com o usuário dele e vende normalmente.
- Cada venda/caixa/estoque é gravada na nuvem automaticamente.
- **Você** abre o mesmo endereço de qualquer lugar, entra como **admin**, e vê tudo atualizando sozinho (a tela sincroniza a cada poucos segundos).
- O indicador no rodapé do menu mostra o status: **Nuvem · sincronizado** quando está tudo certo.

---

## Custos

- **Supabase** e **Netlify** têm planos gratuitos folgados para uma loja (o banco grátis do Supabase guarda muito mais do que um ERP de loja precisa).
- Você só pagaria se o volume crescesse muito (vários milhões de registros / muito tráfego) — improvável para uma loja física.

---

## Aviso de segurança (importante)

Nesta configuração simples, a chave **anon** fica no sistema e quem tiver o endereço + a chave consegue ler/gravar os dados. Para uma loja isso costuma ser aceitável, mas **não** é um cofre. Quando quiser segurança de nível empresarial (login por senha no próprio banco, separação total por usuário, logs de auditoria), o próximo passo é ativar o **Supabase Auth** com políticas por usuário — me chame que eu evoluo o sistema para isso.

## Dúvidas comuns

- **"Conectei mas não aparece nada no outro aparelho"** → confira se os dois usaram a **mesma** URL e chave, e se a tabela `erp_state` foi criada (Parte 1, passo 3).
- **"Deu erro ao conectar"** → quase sempre é a tabela não criada ou a chave/URL copiada errada (sem espaços).
- **"Quero voltar a usar só local"** → em Configurações → Sincronização na nuvem → **Desconectar**.
